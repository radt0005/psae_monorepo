import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const load_get = defineEventHandler(
  (event) => {
    return {};
  }
);

export { load_get as default };
//# sourceMappingURL=load.get.mjs.map
