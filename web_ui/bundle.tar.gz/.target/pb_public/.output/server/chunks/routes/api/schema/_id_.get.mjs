import { d as defineEventHandler, a as getRouterParam, u as useServerPocketbase } from '../../../nitro/nitro.mjs';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const pb = useServerPocketbase();
const _id__get = defineEventHandler(
  async (event) => {
    const name = getRouterParam(event, "id");
    console.log(`Looking for block with name: ${name}`);
    const pbData = await pb.collection("blocks").getFirstListItem(`name="${name}"`);
    const parsed_data = pbData.schema;
    return parsed_data;
  }
);

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
