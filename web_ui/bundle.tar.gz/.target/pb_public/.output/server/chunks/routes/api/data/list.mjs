import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const list = defineEventHandler(
  (event) => {
    return {
      items: []
    };
  }
);

export { list as default };
//# sourceMappingURL=list.mjs.map
