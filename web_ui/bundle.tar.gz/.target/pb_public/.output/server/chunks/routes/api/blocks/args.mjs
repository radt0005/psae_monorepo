import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import fs from 'node:fs/promises';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const args = defineEventHandler(
  async (event) => {
    var _a;
    const params = getQuery(event);
    const name = (_a = params["name"]) == null ? void 0 : _a.toString();
    const slug = name == null ? void 0 : name.replaceAll("::", "-").toLowerCase();
    const filename = `./blocks/${slug}.json`;
    const data = await fs.readFile(filename);
    const data_str = data.toString();
    return JSON.parse(data_str);
  }
);

export { args as default };
//# sourceMappingURL=args.mjs.map
