import { d as defineEventHandler, a as getRouterParam } from '../../../nitro/nitro.mjs';
import path from 'node:path';
import fs from 'node:fs/promises';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler(
  async (event) => {
    const id = getRouterParam(event, "id") || "test";
    const basePath = `/home/krbundy/.psae/runs/`;
    const targetDirectory = path.join(basePath, id);
    const files = await fs.readdir(targetDirectory);
    return {
      files
    };
  }
);

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
