import { d as defineEventHandler, a as getRouterParam } from '../../../../nitro/nitro.mjs';
import path from 'node:path';
import fs from 'node:fs/promises';
import parse from 'csv-simple-parser';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _name__get = defineEventHandler(
  async (event) => {
    const name = getRouterParam(event, "name") || "test";
    const id = getRouterParam(event, "id") || "example.csv";
    const basePath = "/home/krbundy/.psae/runs";
    const filePath = path.join(basePath, id, name);
    const data = await fs.readFile(filePath);
    let response_data;
    try {
      if (filePath.includes(".csv")) {
        response_data = parse(data.toString(), {
          header: true
        });
      } else {
        response_data = JSON.parse(data.toString());
      }
      return response_data;
    } catch (e) {
      console.error(e);
      return {
        error: "File not a valid type"
      };
    }
  }
);

export { _name__get as default };
//# sourceMappingURL=_name_.get.mjs.map
