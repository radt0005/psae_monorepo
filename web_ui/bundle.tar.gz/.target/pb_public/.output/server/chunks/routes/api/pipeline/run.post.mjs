import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import amqplib from 'amqplib';
import crypto from 'node:crypto';
import { r as rng, u as unsafeStringify } from '../../../_/rng.mjs';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import '@iconify/utils';
import 'consola';

const REGEX = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;

function validate(uuid) {
  return typeof uuid === 'string' && REGEX.test(uuid);
}

const native = {
  randomUUID: crypto.randomUUID
};

function v4(options, buf, offset) {
  if (native.randomUUID && true && !options) {
    return native.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80;
  return unsafeStringify(rnds);
}

const RABBITMQ_URL = "amqp://localhost";
const QUEUE_NAME = "user_submissions";
const run_post = defineEventHandler(
  async (event) => {
    const body = await readBody(event);
    const id = body.id;
    const run_id = v4();
    const examplePipeline = `
id: 0195d877-e383-7229-b601-1be1bbc558f6
version: 0.0.1
blocks:
  - id: data-public-fia
    name: data-public-fia
    input: []
    args: {}
  - id: 0195d875-01b0-7229-b600-f1c189c941ce
    name: duckdb-sql-query
    input:
      - data-public-fia
    args:
      query: |-
        SELECT SPCD, DIA, DRYBIO_AG 
        FROM read_csv(?) 
        WHERE INVYR < 2022 
        LIMIT 300;
      path: ""
      bindings: []
      bind_path: ""
  - id: 0195d875-5e62-7229-b600-fe00577d6fa2
    name: random-forest-fit
    input:
      - 0195d875-01b0-7229-b600-f1c189c941ce
    args:
      data_path: ""
      params: {}
      target: DRYBIO_AG
      save_path: ""
  - id: 0195d875-f238-7229-b601-02838f7897b1
    name: random-forest-predict
    input:
      - 0195d875-5e62-7229-b600-fe00577d6fa2
      - 0195d876-4667-7229-b601-0e8f340d1a24
    args:
      data_path: ""
      model_path: ""
  - id: 0195d876-4667-7229-b601-0e8f340d1a24
    name: duckdb-sql-query
    input:
      - data-public-fia
    args:
      query: |-
        SELECT SPCD, DIA
        FROM read_csv(?) 
        WHERE INVYR = 2022 
        LIMIT 100;
      path: ""
      bindings: []
      bind_path: ""
data: []`;
    const message = {
      user_id: id,
      run_id,
      content: examplePipeline
      //body.pipeline as string,
    };
    console.log(message);
    if (validate(id)) {
      const conn = await amqplib.connect(RABBITMQ_URL);
      const channel = await conn.createChannel();
      await channel.assertQueue(QUEUE_NAME, { durable: true });
      const success = channel.sendToQueue(
        QUEUE_NAME,
        Buffer.from(JSON.stringify(message)),
        { persistent: true }
      );
      console.log(message);
      await channel.close();
      await conn.close();
      return {
        success,
        id: run_id
      };
    } else {
      return {
        id: run_id,
        error: "Invalid UUID provided"
      };
    }
  }
);

export { run_post as default };
//# sourceMappingURL=run.post.mjs.map
