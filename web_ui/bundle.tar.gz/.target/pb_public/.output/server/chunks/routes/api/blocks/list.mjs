import { d as defineEventHandler, u as useServerPocketbase } from '../../../nitro/nitro.mjs';
import 'pocketbase';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const pb = useServerPocketbase();
const list = defineEventHandler(
  async (_event) => {
    const pbData = await pb.collection("blocks").getFullList();
    const data = {
      blocks: pbData.map(
        (item) => {
          return {
            name: item.name,
            label: item.label,
            type: "block"
          };
        }
      )
    };
    return data;
  }
);

export { list as default };
//# sourceMappingURL=list.mjs.map
