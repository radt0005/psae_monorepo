import{_ as r}from"./dT6SnfDu.js";import{_ as i}from"./BdzsuCbv.js";import"./CMKT5TnO.js";import{e as p,j as s,w as t,o as l,b as u,a as o}from"./C0yL9o5S.js";import"./CYYIUF_9.js";const b=p({__name:"about",setup(d){return JSON.parse(`{
  "name": "handler",
  "description": "Runs a SQL query against a file using DuckDB",
  "parameters": {
    "type": "object",
    "properties": {
      "path": {
        "type": "string",
        "description": "The path to the database (optional).  If none is provided or the path is invalid, an in-memony database will be used"
      },
      "query": { "type": "string", "description": "The SQL query provided" },
      "bindings": {
        "type": "array",
        "items": {},
        "description": "An optional list of variables to be bound into the query. Defaults to [].",
        "default": []
      }
    },
    "required": ["path", "query"]
  }
}`),(_,e)=>{const n=r,a=i;return l(),s(a,null,{default:t(()=>[u(n,null,{default:t(()=>e[0]||(e[0]=[o("h1",null,"The PSAE App",-1),o("p",null,"A full explanation will go here",-1)])),_:1})]),_:1})}}});export{b as default};
